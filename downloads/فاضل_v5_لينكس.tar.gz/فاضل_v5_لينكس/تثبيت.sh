#!/bin/bash
# مثبّت لغة فاضل v5 — لينكس · §FDL§ م. فاضل عباس الجعيفري
# PREFIX=$HOME/.local (افتراضيّاً، بلا root) أو PREFIX=/usr/local مع sudo
set -e
cd "$(dirname "$0")"
PREFIX="${PREFIX:-$HOME/.local}"
mkdir -p "$PREFIX/bin" "$PREFIX/lib/fdl"
cp bin/fdl "$PREFIX/bin/fdl"; chmod +x "$PREFIX/bin/fdl"
cp lib/fdl/* "$PREFIX/lib/fdl/"
echo "✓ نُصِّب fdl في $PREFIX/bin — والمحرّك (المترجم الخامس) في $PREFIX/lib/fdl"
command -v qemu-system-x86_64 >/dev/null 2>&1 || echo "⚠ ينقصك qemu (ذراع الإقلاع): sudo apt install qemu-system-x86"
case ":$PATH:" in *":$PREFIX/bin:"*) ;; *) echo "⚠ أضف $PREFIX/bin إلى PATH";; esac
"$PREFIX/bin/fdl" --نسخة
echo "جرّب: fdl --فحص ثمّ fdl أمثلة/01_نثر.فضل"
